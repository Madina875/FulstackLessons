const dictRouter = require("./dict.routes");
const catRouter = require("./category.routes");
const descRouter = require("./desc.routes");
const socRouter = require("./social.routes");
const synRouter = require("./syn.routes");
const router = require("express").Router();

router.use("/dict", dictRouter);
router.use("/category", catRouter);
router.use("/desc", descRouter);
router.use("/soc", socRouter);
router.use("/syn", synRouter);

module.exports = router;

//dict , cat
//desc , soc , syn
